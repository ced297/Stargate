package io.swagger.model;

import java.util.Objects;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonCreator;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import javax.validation.Valid;
import javax.validation.constraints.*;

/**
 * TestSequence
 */
@javax.annotation.Generated(value = "io.swagger.codegen.languages.SpringCodegen", date = "2017-10-17T23:19:08.798Z")

public class TestSequence   {
  @JsonProperty("idBandeau")
  private Long idBandeau = null;

  @JsonProperty("niveauRouge")
  private Long niveauRouge = null;

  @JsonProperty("niveauBleu")
  private Integer niveauBleu = null;

  @JsonProperty("niveauVert")
  private Integer niveauVert = null;

  public TestSequence idBandeau(Long idBandeau) {
    this.idBandeau = idBandeau;
    return this;
  }

   /**
   * Get idBandeau
   * @return idBandeau
  **/
  @ApiModelProperty(value = "")


  public Long getIdBandeau() {
    return idBandeau;
  }

  public void setIdBandeau(Long idBandeau) {
    this.idBandeau = idBandeau;
  }

  public TestSequence niveauRouge(Long niveauRouge) {
    this.niveauRouge = niveauRouge;
    return this;
  }

   /**
   * Get niveauRouge
   * @return niveauRouge
  **/
  @ApiModelProperty(value = "")


  public Long getNiveauRouge() {
    return niveauRouge;
  }

  public void setNiveauRouge(Long niveauRouge) {
    this.niveauRouge = niveauRouge;
  }

  public TestSequence niveauBleu(Integer niveauBleu) {
    this.niveauBleu = niveauBleu;
    return this;
  }

   /**
   * Get niveauBleu
   * @return niveauBleu
  **/
  @ApiModelProperty(value = "")


  public Integer getNiveauBleu() {
    return niveauBleu;
  }

  public void setNiveauBleu(Integer niveauBleu) {
    this.niveauBleu = niveauBleu;
  }

  public TestSequence niveauVert(Integer niveauVert) {
    this.niveauVert = niveauVert;
    return this;
  }

   /**
   * Get niveauVert
   * @return niveauVert
  **/
  @ApiModelProperty(value = "")


  public Integer getNiveauVert() {
    return niveauVert;
  }

  public void setNiveauVert(Integer niveauVert) {
    this.niveauVert = niveauVert;
  }


  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    TestSequence testSequence = (TestSequence) o;
    return Objects.equals(this.idBandeau, testSequence.idBandeau) &&
        Objects.equals(this.niveauRouge, testSequence.niveauRouge) &&
        Objects.equals(this.niveauBleu, testSequence.niveauBleu) &&
        Objects.equals(this.niveauVert, testSequence.niveauVert);
  }

  @Override
  public int hashCode() {
    return Objects.hash(idBandeau, niveauRouge, niveauBleu, niveauVert);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class TestSequence {\n");
    
    sb.append("    idBandeau: ").append(toIndentedString(idBandeau)).append("\n");
    sb.append("    niveauRouge: ").append(toIndentedString(niveauRouge)).append("\n");
    sb.append("    niveauBleu: ").append(toIndentedString(niveauBleu)).append("\n");
    sb.append("    niveauVert: ").append(toIndentedString(niveauVert)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}

