# TestsequenceApi

All URIs are relative to *http://localhost:8080/stargate/v1*

Method | HTTP request | Description
------------- | ------------- | -------------
[**allumerLedBandeau**](TestsequenceApi.md#allumerLedBandeau) | **POST** /testsequence/AllumeBandeau | Allume toutes les led d&#39;un bandeau d&#39;une couleur 
[**eteindre**](TestsequenceApi.md#eteindre) | **POST** /testsequence/Eteindre | Eteint toutes les led de tous les bandeaux


<a name="allumerLedBandeau"></a>
# **allumerLedBandeau**
> allumerLedBandeau(body)

Allume toutes les led d&#39;un bandeau d&#39;une couleur 



### Example
```java
// Import classes:
//import io.swagger.client.ApiException;
//import io.swagger.client.api.TestsequenceApi;


TestsequenceApi apiInstance = new TestsequenceApi();
TestSequence body = new TestSequence(); // TestSequence | numero du bandeau et couleur pour l'alumage
try {
    apiInstance.allumerLedBandeau(body);
} catch (ApiException e) {
    System.err.println("Exception when calling TestsequenceApi#allumerLedBandeau");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**TestSequence**](TestSequence.md)| numero du bandeau et couleur pour l&#39;alumage |

### Return type

null (empty response body)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="eteindre"></a>
# **eteindre**
> eteindre()

Eteint toutes les led de tous les bandeaux



### Example
```java
// Import classes:
//import io.swagger.client.ApiException;
//import io.swagger.client.api.TestsequenceApi;


TestsequenceApi apiInstance = new TestsequenceApi();
try {
    apiInstance.eteindre();
} catch (ApiException e) {
    System.err.println("Exception when calling TestsequenceApi#eteindre");
    e.printStackTrace();
}
```

### Parameters
This endpoint does not need any parameter.

### Return type

null (empty response body)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/xml, application/json

