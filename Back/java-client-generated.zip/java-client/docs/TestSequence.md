
# TestSequence

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**idBandeau** | **Long** |  |  [optional]
**niveauRouge** | **Long** |  |  [optional]
**niveauBleu** | **Integer** |  |  [optional]
**niveauVert** | **Integer** |  |  [optional]



